import os
scraper = os.system('chmod +x rom && ./rom')
print(scraper)
